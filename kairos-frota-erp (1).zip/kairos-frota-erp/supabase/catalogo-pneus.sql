-- =====================================================================
--  KAIROS FROTA — Catálogo de Pneus (Marca → Modelo → Medida)
--  Estrutura RELACIONAL com chaves estrangeiras, índices e RLS.
--
--  Observação importante:
--  O app Kairos Frota persiste os dados como documentos jsonb em
--  public.app_state (domínios tireBrands / tireModels / tireSizes),
--  o que já mantém os relacionamentos por id no front-end e funciona
--  sem este arquivo. Estas TABELAS RELACIONAIS são opcionais e servem
--  para quem quiser consultas SQL diretas, integridade no banco e BI
--  (Power BI, etc.). Rode-as DEPOIS de schema.sql. São idempotentes.
-- =====================================================================

-- ---------- MARCAS ----------
create table if not exists public.tire_brands (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null default auth.uid(),
  nome       text not null,
  codigo     text,
  logo_url   text,
  created_at timestamptz not null default now(),
  unique (org_id, lower(nome))           -- evita marca duplicada por organização
);

-- ---------- MODELOS (pertencem a uma marca) ----------
create table if not exists public.tire_models (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null default auth.uid(),
  marca_id    uuid not null references public.tire_brands(id) on delete restrict,
  nome        text not null,
  desenho     text,
  qtd_sulcos  int,
  mm_novo     numeric(5,2),
  codigo      text,
  created_at  timestamptz not null default now(),
  unique (org_id, marca_id, lower(nome)) -- modelo único dentro da marca
);

-- ---------- MEDIDAS ----------
create table if not exists public.tire_sizes (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null default auth.uid(),
  nome       text not null,                -- padronizada em maiúsculas pelo app
  created_at timestamptz not null default now(),
  unique (org_id, upper(nome))             -- evita medida duplicada
);

-- Índices de apoio
create index if not exists tire_models_marca_idx on public.tire_models (marca_id);
create index if not exists tire_brands_org_idx   on public.tire_brands (org_id);
create index if not exists tire_models_org_idx   on public.tire_models (org_id);
create index if not exists tire_sizes_org_idx    on public.tire_sizes (org_id);

-- ---------- RLS: cada organização só acessa o próprio catálogo ----------
alter table public.tire_brands enable row level security;
alter table public.tire_models enable row level security;
alter table public.tire_sizes  enable row level security;

do $$
declare t text;
begin
  foreach t in array array['tire_brands','tire_models','tire_sizes'] loop
    execute format('drop policy if exists %I_sel on public.%I', t, t);
    execute format('create policy %I_sel on public.%I for select using (org_id = auth.uid())', t, t);
    execute format('drop policy if exists %I_ins on public.%I', t, t);
    execute format('create policy %I_ins on public.%I for insert with check (org_id = auth.uid())', t, t);
    execute format('drop policy if exists %I_upd on public.%I', t, t);
    execute format('create policy %I_upd on public.%I for update using (org_id = auth.uid()) with check (org_id = auth.uid())', t, t);
    execute format('drop policy if exists %I_del on public.%I', t, t);
    execute format('create policy %I_del on public.%I for delete using (org_id = auth.uid())', t, t);
  end loop;
end $$;

-- ---------- View de consulta amigável (marca + modelo + medida) ----------
create or replace view public.v_tire_catalog as
  select mo.id            as modelo_id,
         mo.nome          as modelo,
         br.nome          as marca,
         mo.desenho,
         mo.qtd_sulcos,
         mo.mm_novo,
         br.id            as marca_id,
         mo.org_id
  from public.tire_models mo
  join public.tire_brands br on br.id = mo.marca_id;

-- =====================================================================
--  FIM — Catálogo de Pneus
--  Integridade garantida:
--   • um modelo NÃO pode existir sem marca (FK NOT NULL + on delete restrict)
--   • marca com modelos não pode ser apagada (restrict) — o app também bloqueia
--   • medidas reutilizáveis entre marcas/modelos (tabela independente)
-- =====================================================================
